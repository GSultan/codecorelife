# morning cohort 15!

# design, idea, concept
# class - class names are Capitalized, and CamelCased.
# ThisIsAnExampleOfCamelCase
class Cookie
end

# baking, building, constructing
# object
