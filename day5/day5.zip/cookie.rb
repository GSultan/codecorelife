class Cookie
  attr_accessor :sugar
  attr_accessor :flour

  def eat
    "Yummy...!"
  end
end
