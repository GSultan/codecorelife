# require './food.rb'
require './pizza.rb'
require './beer.rb'

food = Food.new(10, 20, 15)
pizza = Pizza.new(10, 20, 15, 30)
beer = Beer.new(10, 20, 15, 375)
