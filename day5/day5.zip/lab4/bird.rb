require "./animal.rb"

class Bird < Animal
  def initialize(name)
    super(name)
  end

end
