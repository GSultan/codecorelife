# array is another data type
# an indexed list of information
my_array = []
my_array = [1,2,3]
my_array = Array.new
my_array = ["Jacob", 37, 140.5, [1,2,3]]
