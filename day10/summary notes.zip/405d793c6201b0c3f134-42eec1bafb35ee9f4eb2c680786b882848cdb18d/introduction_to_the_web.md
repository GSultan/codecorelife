# Introduction to the Web
The web is based on many layers of technologies that use protocols to establish communications between the different machines.
## Models
There are two primary models to look at networking protocols and there are: OSI and TCP/IP.
Layers per OSI model: Physical > Data Link > Network > Transport > Session > Presentation > Application
Layers per TCP/IP model: Network Interface > Network > Transpost > Application

There are many protocol in each layer. We will examine a few of them that are most relevant to web applications. We will be looking at things from the TCP/IP model.

## Network Interface Layer
This layer is mainly concerned of transforming the frames from your computer that are essentially a series of ones and zeros into a signal of some sort that can be transmitted over a medium. For instance it may transfer the frames into an electrical signal that goes over a wire or a radio wave signal that travels through the air.

An example protocol at this layer is the Ethernet protocol.

## Network Layer
This layer is mainly concerned about the mechanism of reaching remote machines. A popular example protocol is the IP protocol which powered the web. IPs are unique identifiers that identify a remote machine so two machines can communicate with each others.
### IPv4
The version 4 of IP has been around for a long time and it's a way to give an address to a machine composed of four sections, each composed of 8 bits. Consequently, we can only assign a maximum of about 4.3 billion IP addresses.

IPs are used by the computer and router in order to direct frames over the Internet to reach from a machine to a machine, mainly from a client to a server.
### IPv6
IPv6 was introduced to solve the problem of running out of available IPs to assign. It uses eight groups of four hexadecimal digits so it can support many more IP addresses than IPv4.
### DNS
Because remembering and typing IPs can be cumbersome, a system exists called DNS which stands for Domain Name System whose main function is to translate a domain name (such as `codecore.ca`) to an IP address such as `23.226.230.108`. There are many domain registrars that help us assign domain names to IP addresses. With DNS you can set `A` records to assign a domain name to IP addresses. You can also assign `MX` records in order to communicate with mail servers.
### ICMP
ICMP stands for Internet Control Message Protocol which is a protocol at the network layer which is used mainly to check the status of a networking device such as routers. It's used by programs like `ping` to test the reachability of a specific machine or website.

## Transport Layer
Transport layer is concerned about the mechanism where chunks of data are sent received and error checked. There are two primary protocols that are used for the transport layer and those are the `TCP` protocol and the `UDP` protocol.
### TCP
TCP protocol is a reliable, ordered and connection based protocol. It uses and handshake mechanism to ensure that data is transmitted and received correctly. It's used in situations where you want to make sure that data is received reliably at the other end. TCP utilizes ports which are 8 bit numbers to know the apps that are making the TCP request. Only one application can be listening on a given port. TCP powers many of the protocols like HTTP and SSH.
### UDP
UDP protocol is similar to the TCP protocol except that it doesn't require a handshake so it's less reliable and packet could be received in a non-ordered fashion. It has less overhead than TCP so it's used in situations where speed matters such as video and audio conversations over the internet.

## Application Layer
This layer is where applications make use of the protocol stack in the other layers to achieve its task. An example protocol here is the `HTTP` protocol that uses `TCP` and `IP` to power the web.

### HTTP
The HTTP protocol is what power most of the web these days. It depends on `TCP` and `IP` to work. HTTP has a lot of specifications and details but here are the main things that we will be using to build web applications:

#### URL
URL is what's used to identify the host and port number. URL looks like this: `http://mydomain.com:8080/hello`. In many circumstances you don't need to specify the ports as the detail port will be `80`.

#### VERB
HTTP verbs are used in some standards to route the application correctly. We will be using it as we implement the `REST` architecture. There are many available verbs. We will be using those ones: `GET`, `POST`, `PATCH`, `PUT` and `DELETE`

#### Response Codes
HTTP returns a number that is the response code whether the request was successful, rejected or the server threw an error. There are also many codes but we will primarily use: 200: success, 500: server error, 404: not found, 403/401: not authorized and 301: redirect

### HTTP Servers
HTTP servers work by listing on a specific TCP port. You can think of them like an infinite loop that keeps listening for new incoming data for that port.

### Using Node.js with TCP
We can use Node.js to build a simple TCP application as in:
```javascript
var net = require("net");

var server = net.createServer(function(socket){
  socket.on("data", function(data){
    console.log("Data received on server: " + data);
    socket.write("Roger, " + data);
  });
});

server.listen(5000, "127.0.0.1");
```
This enables us to build a server that listens on port `5000` and IP address `127.0.0.1`.

We can build a client application with Node.js as well to connect to that server:
```javascript
var net = require("net");

var client = new net.Socket();
client.on("data", function(data){
  console.log("Data Received from server: " + data);
});


client.connect(5000, "127.0.0.1", function(){
  client.write(name);
});
```

### Using Rack with HTTP
We can use Ruby `Rack` gem to build a simple HTTP server as in:
```ruby
require "rack"

class MyApp
  def self.call(env)
    [200, {"Content-Type" => "text/html"}, ["Hello world"]]
  end
end

Rack::Handler::WEBrick.run MyApp
```
We can connect to that app using a browser by typing `http://localhost:8080/` (default port used by Rack is 8080).