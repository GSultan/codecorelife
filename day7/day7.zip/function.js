// javascript
function capitalize(string) {
  // to capitalize the string coming in
  // there is no string.capitalize() method built into javascript
  // please build one!
  return string.charAt(0).toUpperCase() + string.slice(1);
}

console.log(capitalize("jacob"));

// # ruby
// def capitalize(name)
// end
//
// capitalize "jacob"
