// hello cohort 15!

// single line comment

/*
    Multiline comment
*/

/*
 *
 *    Multiline comment
 *
 */

// a = 10
// name = "Jacob"
//
// var a = 10;
// var name = "Jacob";
//
// console.log("Hello 15s!!!");
// console.log(a);
// console.log(name);
//
// first_name # snake_case
//
// firstName = "Jacob" // camelCase
//
// var i = 10;
// console.log(i / 3);
// console.log(i * 2);
// console.log(i % 4);
//
// // x = 10
// // y = x + 2
//
// var x = 10;
// var y = x + 2;
//
// // strings
//
// "" // regular string - this is a string that will mutate
// '' // string literal - this is a string that will not
//
// "This is a string"
// 'This is also a string'
//
// 'This is \n on a new line'
//
// "Quote's inside"
// 'Quote"s inside'
//
// "Quote\"s inside"
//
// 'Quote\'s inside "this string"'
//
// "one" + "two" // "onetwo"
// "#{one}#{two}" // no string interpolation in vanilla javascript
// // there is string interpolation in jquery
//
// 'A' + " " + 'B'; // "A B" string
// '4' + 5; // "45" string
// 5 + '4'; // "54" string
//
//
// var _abc = "hello";
// var $lol = "there";
// var 123abc = "wat"; // will fail, you cannot start a variable name with a number
// var _123abc = "yes";
//
// var x = 10, y = 5, z = 3;
//
// // truthy language
// if (true) {
//   console.log("Hello");
// }
//
// if true
//   puts "Hello"
// end
//
// if (true) {
//   console.log("Hello");
// } else {
//   console.log("World");
// }
//
// if (1) { // any number other than 0 will create a true condition
//           // negative numbers will also create a true condition
//   console.log("Hello");
// } else {
//   console.log("World");
// }
//
// if (0) { // zero will create a false condition
//   console.log("Hello");
// } else {
//   console.log("World");
// }

// exercise
var string1 = "Hello, ";
var string2 = "Jacob ";
var string3 = "Tran";

console.log(string1 + string2 + string3);
console.log(string1.length + string2.length + string3.length);

// strings in ruby, are sort of like, an array of characters
// strings are an array of characters

typeof(string1); // string
string1[0];

if (true) {
  console.log("inside if");
}


if (!true) {
  console.log("inside if");
}






//
