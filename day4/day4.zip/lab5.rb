# Assignment: [lab] Find the repeated number Edit Next Module
#
# You are given an array with numbers between 1 and 1,000,000. One integer is in the array twice. How can you determine which one? Can you think of a way to do it using little extra memory.
#
# Bonus: Solve it in two ways: one using hashes and one without.

# return to us an array to lab 5
def arr_create(num)
  # rand(num) will generate a random number between 0 - num
  (0..num).to_a << rand(num)
  (1..num).to_a << rand(1..num)
end

p arr_create(1000000)
