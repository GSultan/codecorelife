# morning 15s!!!

# dictionary = {}
# dictionary = Hash.new
#
# dictionary = { "book" => "collection of written words on pages" }
# # hashes are made up of keys and values, separated by the rocket (=>)
#
# # array[1]
#
# puts dictionary["book"]
#
# # keys, they must be unique
# me = {  "name" => "Jacob",
#         "age" => 37,
#         "birth_place" => "Hanoi"
#       }
#
# puts me["name"]
# puts me["age"]
# puts me["birth_place"]
# p me["birth_date"] # if you access a key that doesn't exist, it returns nil
#
# puts me.fetch("name")
# puts me.fetch("age")
# puts me.fetch("birth_place")
# # puts me.fetch("birth_date") # fetch will raise an error if the key doesn't exist
# puts me.fetch("address", "not specified") # this allows us to return a default value if the key is not specified
#
# # car hash
# car = { "Honda" => "Civic",
#         "Toyota" => "Corolla",
#         "Mazda" => "Miata" }
#
# car.keys # this will give you an array of keys
# grabbing key from a specied value

# dictionary = Hash.new("unknown")
# dictionary = Hash.new(0)
# # dictionary = Hash.new("unknown") # default value for any key
# p dictionary["pulp2"] = "soft, watery paper"
# p dictionary["pulp"] = "soft, watery paper"
# p dictionary["fiction"] = "imaginary literary work"
# p dictionary["tarantino"] # key will not be created until a corresponding value is assigned
# # p dictionary.keys
#
# # metaphors: postal codes, library card catalog, username + acct number
#
# # p "can we access hash by index?"
# dictionary[100] = "future"
# dictionary[0] = 5
# dictionary[1] = 32
# dictionary[2] = 24601
# p dictionary[0]
# p dictionary[1]
# p dictionary[2]
# p dictionary[0] * dictionary[1] * dictionary[2]
# p dictionary.keys
#
# dictionary.default = "codecore"
#
# p dictionary["welcome"]
#
# p dictionary.keys # will return all the keys in our hash in the form of an array
# p dictionary.values # will return all the values in our hash in the form of an array
#
# dictionary.keys.each do |key|
#   puts key
# end
#
# dictionary.values.each do |value|
#   puts value
# end
#
# dictionary.each do |pair|
#   p pair # we get an array containing key and value
# end
#
# dictionary.each do |key, value|
#   puts "key is #{key} and value is #{value}"
# end
#
# p dictionary.key("soft, watery paper") # this is the answer to ben's question
#
# provinces = { "BC" => "Victoria",
#               "AB" => "Edmonton",
#               "PEI" => "Charlottetown" }
#
# # provinces.each do |province_and_capital|
# provinces.each_pair do |province_and_capital|
#   puts "#{province_and_capital.last}, #{province_and_capital.first}"
#   # puts "#{province_and_capital[1]}, #{province_and_capital[0]}"
# end
#
# provinces.each_key {|k| puts k}
# provinces.each_value {|v| puts v}
#
# # V5B 2C9 !??!!
# # 000 000
#
#  city_ratings = {“Vancouver” => 10, “Richmond” => 8, “Burnaby” => 7}
#  city_ratings.each_key { |province| puts province }
#  city_ratings.each_value { |rating| puts rating }

# Hashes and Arrays
# canada =  {
#               "BC" => ["Vancouver", "Richmond", "Burnaby"],
#               "AB" => ["Red Deer", "Calgary", "Edmonton"],
#               "ON" => ["Hamilton", "Toronto", "Sudbury", "Kingston", "Ottawa"]
#           }
#
# # PRINT OUT THE FOLLOWING:
# # The province of BC has the following cities:  Vancouver, Richmond and Burnaby.
#
# # As a stretch, have the "and" always appear before the last city, regardless of the number of cities
# canada.each do |province, cities|
#
#   cities_string = "" # clears out the list of cities from the previous province
#
#   cities.each_with_index do |city, index|
#     # if the city is the last city
#     if (index == cities.length-1)
#       cities_string += "and #{city}."
#     else
#       cities_string += "#{city}, "
#     end
#
#   end
#
#   puts "The province of #{province} has the following cities: #{cities_string}"
#
# end
#
# # Build an array that contains two hashes. Each hash should be personal info about a person
# # (first_name, last_name, and age)
#
#
# person1 = {
#   "first_name" => "Jacob"
#   "last_name" => "Tran"
#   "age" => 37
# }
# person2 = {
#   "first_name" => "Tam"
#   "last_name" => "Kbeili"
#   "age" => 24
# }
#
# teachers = [ person1,
#              person2 ]
#
#
#
# teachers = [
#   person1 = {
#     "first_name" => "Jacob"
#     "last_name" => "Tran"
#     "age" => 37
#   },
#   person2 = {
#    "first_name" => "Tam"
#    "last_name" => "Kbeili"
#    "age" => 24
#   }
# ]
#
# # print out the first name and last name of each teacher
# teachers.each do |teacher|
#   puts "#{teacher['first_name']} #{teacher['last_name']}"
# end
#
# # array we use [] to contruct
# my_array = []
# # in arrays, we also use [] to retrieve information from our array
# my_array[2] # grabs the value at the index of 2
#
# # hash - define a hash using {}
# my_hash = {}
# # when we retrieve values in our hash, we need to specify a key, instead of an index
# my_hash["name"]
#
# # string interpolation, we must use the following:
# #{}
# # only used when we are printing out or storing in a string: "#{}"
#
# my_array.each {|x| puts x}

# symbol
# we define symbols as the key for our hash to improve performance when looking up our hash

a = "BC"
b = :bc # symbol is prefixed with a colon
# strings are mutable, symbols are immutable

a.object_id
b.object_id

my_hash = {:a => 1, :b => 2, :c => 3, :d => :a}
p my_hash[:a]
p my_hash[:d]

"bc".to_sym # :bc
:bc.to_s # "bc"

my_info = {
  :name => "Jacob",
  :city => "Vancouver",
  :favourite_food => "Sushi",
  :favourite_sport => "MMA",
  :age => 37
}

p my_info[:name]
p my_info[:city]
p my_info[:age]

my_info = {
  name: "Jacob",
  city: "Vancouver",
  favourite_food: ["Sushi", "Pizza"],
  favourite_sport: "MMA",
  age: 37
}

# symbols can have the colon at beginning or end

# we want to print Pizza
# when we access values using symbols, we must put the colon at the start
p my_info[:favourite_food][1]


# TURN THIS ARRAY
input = ["hello", "greetings", "hola", "hi"]

# INTO THIS HASH
# {   hello: 5,
#     greetings: 9,
#     hola: 4,
#     hi: 2
# }

new_hash = {}

# input.each do |greeting|
#   new_hash[greeting.to_sym] = greeting.length
# end

for i in 0..input.length-1
  symbol = input[i].to_sym
  new_hash[symbol] = input[i].length
end

p new_hash

















#
