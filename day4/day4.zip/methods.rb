# methods in ruby start with a definition

# def say_hello
#   puts "Hello Everyone!"
# end
#
# say_hello()
# say_hello
#
# # in ruby the last line of your method is automatically returned
# def multiply
#   results = []
#   results << 5 * 6
#   results << 1 + 1
#   results << 2 * 2
# end
#
# puts multiply
#
# def multiply(a, b)
#   a * b
# end
#
# p multiply(2, 2)
#
# # write a method that takes in 2 arguments and produces the sum of those 2 arguments
# def sum(a, b)
#   a + b
# end
#
# p sum(2, 5)
#
# def power_it(a, b)
#   a ** b
# end
#
# p power_it(2, 3)

# howard - can methods take in a variable number of arguments?
# def sum(*c)
#   total = 0
#   c.each do |num|
#     total += num
#   end
#
#   total
# end
#
# p sum(2, 5, 10, 12, 13, 15, 1, 45, 34)
# p sum("Derp")

# what is it!?!?

# chris
# def checker(arg)
#   if arg.class == String
#     "arg is a string"
#   elsif arg.class == Fixnum
#     "arg is an integer"
#   elsif arg.class == Array
#     "arg is an array"
#   else
#     "arg is something else"
#   end
# end
#
# puts checker "Hello"
# puts checker 5
# puts checker [1,2,3]
# puts checker true

# def arg(x)
#   if (x.is_a? Array)
#     puts "Is an Array"
#   elsif (x.is_a? String)
#     puts "Is a String"
#   elsif (x.is_a? Integer)
#     puts "Is an Integer"
#   else
#     puts "Something else"
#   end
# end
#
# arg "Hello"
# arg 5
# arg [1,2,3]
# arg true
#
# # guy - case when
def classifier(x)
  case x
  when String
    puts "It was a string"
  when Integer
    puts "It was an integer"
  when Array
    x.each do |value|
      classifier value
    end
    puts "It was an array"
  else
    puts "It was something else"
  end
end

def classifier(x)
  case x.class.to_s
  when "String"
    puts "It was a string"
  when "Fixnum"
    puts "It was an integer"
  when "Array"
    x.each do |value|
      classifier value
    end
    puts "It was an array"
  else
    puts "It was something else"
  end
end
#
# classifier "A"
classifier 5
# classifier ["Hello World", 1, true, nil]
# classifier true
# classifier % # math function called modulo
# classifier $ # global variables

def johnny(arg)
  if arg.class == String || arg.class == Fixnum || arg.class == Array
    puts arg.class
  else
    puts "Something else"
  end
end

johnny "A"
johnny 5
johnny ["Hello World", 1, true, nil]
johnny true

# optional parameters
def sum(a=0, b=1)
  # 0 + 1
  a + b
end

p sum()

# boolean methods
def cool?(name)
  if (name == "Jacob" || name == "Sandra")
    return true
  else
    return false
  end
end

p cool? "Jacob"
p cool? "Nari"
p cool? "Jose"
p cool? "Sandra"

# is_a? will only return true or false




#
