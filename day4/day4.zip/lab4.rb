# Assignment: [lab] Implement Pluck method
#
# Implement a pluck method, which takes an array of hashes and a key name, and returns an array containing the values for each named key in the hash.
#
# For example:
#
# pluck([{a:1}, {a:2}], :a)  ## returns [1,2]
# pluck([{b:2}, {a:4, b:4}, {a:1}, {c:4}], :a) ## returns [nil, 4, 1, nil]
# pluck([{b:2}, {a:4, b:4}, {a:1}, {c:4}], :b) ## returns [2,4,nil,nil]
# If an hash is missing the property, you should just leave it as nil in the output array.
#
# http://www.codewars.com/dojo/katas/530017aac7c0f49926000084

# pluck method takes in 2 arguments: hash_array and the key we want to pluck
def pluck (array_of_hashes, pluck_key)
  # initalize an array to store the matching key values
  new_array = []

  # iterate through the array of hashes
  array_of_hashes.each do |hash|
    # push into the new_array the corresponding value for the matching key
    new_array.push( hash[pluck_key] )
  end
  
  p new_array
end

pluck([{b:2}, {a:4, b:4}, {a:1}, {c:4}], :b)
