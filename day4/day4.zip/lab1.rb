# Assignment: [lab] Hash of information
#
# Ask the user for personal information: first name, last name, city of birth and age. Then store that information in a hash. After that loop through the hash and display the results, for example:
#
# Your first name is Tam.
#
# Capitalize the inputs from the user if they are capitalizable
my_hash = {}

puts "what is your first name?"
first_name=gets.chomp.capitalize
my_hash[:first_name]=first_name

puts "what is your last name?"
last_name=gets.chomp.capitalize
my_hash[:last_name]=last_name

puts "what is your age?"
age=gets.chomp
my_hash[:age]=age

puts "what is your city of birth?"
city=gets.chomp.capitalize
my_hash[:city]=city

first_name=my_hash[:first_name]
puts "My first name is #{first_name}"

last_name=my_hash[:first_name]
puts "My last name is #{last_name}"

age=my_hash[:age]
puts "My age is #{age}"

city=my_hash[:city]
puts "My city is #{city}"

# Thaisa
my_hash.each do |info, value|
  puts "Your #{info} is #{value}"
end

# each and each_pair will work the same when dealing with hashes
# we can get the key and value seperately |key, value| OR combined in the form of an array |pair|

# my_hash.each do |pair|
#   p pair # returns your key, value pair in the form of an array
# end
#
# my_hash.each_pair do |pair|
#   p pair # returns your key, value pair in the form of an array
# end
#
# my_hash.each_pair do |info, value|
#   # p pair
#   puts "Your #{info} is #{value}"
#   # puts "Your #{info} is #{value}"
# end











#
