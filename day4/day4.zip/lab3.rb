# Assignment: [lab] Most recurring letter
#
# Find the most recurring letter in a given string from the user

# If the user enters in "Welcome to the dark side" ...
# the following hash would be built

# {
#   W: 1,
#   e: 4,
#   l: 1,
#   c: 1,
#   o: 2,
#   .
#   .
#   .
# }

# Which will allow us to determin the most reoccuring letter!
# "e" occurs most often

# song

my_array= "welcome tooo the dark side"
my_array = my_array.gsub(" ","").split("")
hash = Hash.new(0)
my_array.each {|key| hash[key] +=1}

# p hash
# p hash.values # [1, 4, 1, 1, 4, 1, 2, 1, 2, 1, 1, 1, 1, 1]
# p hash.values.max # 4
# # p hash.key(hash.values.max)

hash.each do |letter, frequency|
  # hash.values -  takes the values from our hash and turns it into an array of numbers
  # hash.values.max - will pull out the largest number from that array of numbers

  # if the value from our each do iterator matches that max value, print out the corresponding key (the letter).
  if frequency == hash.values.max
    puts "Letter #{letter} occurs the most at #{frequency} times!"
  end
end


# p [1,2,3,4,5,6,81749839287434,3,5,7,89,10].max
# p ['a', 'b', 'c', 'z', 'zz', 'aa'].max






#
