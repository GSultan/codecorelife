# Assignment: [lab] Frequency of numbers
#
# Given an array of number such as:
# 1
# array = [1,2,3,4,4,4,2,3,3,3]
#
# Write a piece of code that will generate a hash of frequencies that looks like:
# 1
# {1 => 1, 2 => 2, 3 => 4, 4 => 3}
# Stretch: Attempt to do the exercise in one line of code using methods like `each_with_object`.
array = [1,2,3,4,4,4,2,3,3,3]
freq={}

array.each do |num|
  if freq[num]!=nil
    freq[num]+=1
  else
    freq[num]=1
  end
end

puts freq

# freq=Hash.new(0)
# array.each do |num|
#     freq[num]+=1
# end
#
# puts freq



p array.each_with_object(Hash.new(0)) { |number, frequency| frequency[number] += 1}

array = [1,2,3,4,4,4,2,3,3,3]

# here is an example of each_with_object, writing to an array
my_array = array.each_with_object([]) do |i, a|
   a << i*2
end

# here is an an example of each_with_object, writing to a hash
# each with object takes in as an argument the object type you would like to
# store the result in
my_hash = array.each_with_object(Hash.new(0)) do |value, hash| # the 2 variables here 1) are the values of the array that each_with_object function is being run on.  2) the object you would like to store the result in.

  # the reason we need to use Hash.new(0) instead of just {}, is that we are doing mathematical manipulation to the value.  If we do not specify a default value, it will return nil.  We cannot += 1 to a nil value, it must be a valid number

  # we use the value as the key, so that we can count the # of occurances for a specific number.
  hash[value] += 1

end

p my_array
p my_hash









#
